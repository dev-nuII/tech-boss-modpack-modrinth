# Boss-Gated Progression Package v3 (draft)

Unzip into your instance root so `kubejs/` and `config/` sit beside `mods/`.
**Add two mods first:** KubeJS (2101.x for 1.21.1 NeoForge) and Rhino. Architectury is already in your pack.
Not play-tested. Run the checklist at the bottom before trusting it.

## Textures
Custom 16x16 pixel art for all four catalysts lives in `kubejs/assets/kubejs/textures/item/`. Replace any PNG with your own (same filename) and reload.
If an item is missing in-game, open `logs/kubejs/startup.log` and look for a script error; the startup script registers all four items.

## The ladder

| # | Boss | Catalyst | Unlocks |
|---|---|---|---|
| 1 | Skor, the Yeti | Frostbound Core | Diamond-tier Sophisticated Storage (chests, barrels, shulkers, double chests, limited barrels, diamond tier upgrades, stack upgrade tier 4) |
| 2 | Sirok, the Sandworm | Sirok's Fang | Mekanism **Elite** control circuits (so Elite tier everything) and AE2 **64k** cell components |
| 3 | Helvar, the Underworld Knight | Helvar's Sigil | Netherite ingot crafting (and with it every netherite-tier storage recipe) |
| 4 | Nerakyss, the Kraken | Nerakyss's Abyssal Pearl | AE2 **256k** cell components, which MEGA cells build on |
| 5 | Wither | Nether Star (vanilla) | Mekanism **Ultimate** control circuits; Draconic Wyvern Core (already requires one) |
| 6 | Ender Dragon | Dragon's Breath (vanilla) | NASA Workbench (the only place Ad Astra rockets are built); Draconium via dragon dust |
| 7 | Chaos Guardian | Chaos fragments (Draconic) | Chaotic tier. Already gated by Draconic's own recipes, nothing added |

Not assigned: Ashlord (the Infernal Dragon) and the Warden. Ashlord is a natural gate for Mekanism Extras' post-Ultimate tiers.

**Farmable once obtained:** Fang, Core, Sigil and Pearl duplicate (1 -> 2), like vanilla smithing templates.
- Core: 4 blue ice + 4 gold ingots + 1 Core
- Fang: 4 cactus + 4 gold ingots + 1 Fang
- Sigil: 4 soul sand + 4 nether wart + 1 Sigil
- Pearl: 4 ink sacs + 4 prismarine crystals + 1 Pearl
Wither and Ender Dragon can be re-summoned, so their gates are farmable by nature.

## Mekanism circuits
Elite and Ultimate circuits now come only from a crafting-table recipe: 4 alloys + 4 lower circuits + 1 catalyst -> 3 circuits (roughly cost-neutral). The Metallurgic Infuser routes and the Evolved Mekanism Extras alloyer routes for these two circuits are disabled so they cannot bypass the gate. Oritech's atomic forge routes are also disabled (harmless if you remove Oritech).

## Other changes
- Underworld Arena vault no longer rolls netherite ingots, scrap, or ancient debris.
- Skor, Sirok, Helvar, Nerakyss keep all original drops plus one guaranteed catalyst.
- `config/l2configs/l2hostility-server.toml`: healthFactor 0.03->0.04, damageFactor 0.02->0.025, dimensionFactor 10->20, killsPerLevel 30->20. These are my starting guesses, not tested balance. Revert any line you dislike.

## Test checklist (creative test world)
1. `/give @s kubejs:sirok_fang` etc. All four items exist with names and icons.
2. JEI: the recipes above show the catalyst. Netherite ingot shows 4 scrap, 4 gold, 1 Sigil.
3. JEI: search every Mekanism "Elite/Ultimate Control Circuit". Only the new crafting recipe should appear. Any other source is a leak.
4. Craft a diamond chest from a gold chest; contents and upgrades must carry over.
5. `/summon` each boss and confirm the catalyst drop.
6. Craft one NASA Workbench.

## Known gaps
- Bastion chests can still contain loose netherite ingots. Closing that needs a loot-modification mod (e.g. LootJS).
- Diamond Sophisticated Backpacks are not gated yet.
- Advanced AE, ExtendedAE or other add-ons may have their own storage cell recipes that skip the AE2 components. Check JEI.
- Draconium can also come from draconium ore, if it generates in your world, which skips the dragon-dust path.
- Raw diamonds cannot be gated; only recipes that consume them.

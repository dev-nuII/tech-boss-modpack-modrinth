// Boss catalyst items. Each is dropped by one boss and is consumed when crafted with. Mass production is only via Hostile Neural Networks (see server_scripts/catalyst_consumable.js).
// Textures are custom 16x16 PNGs in kubejs/assets/kubejs/textures/item/<id>.png (picked up automatically).
StartupEvents.registry('item', event => {
  event.create('frostbound_core')
    .displayName('Frostbound Core')
    .rarity('rare')
    .tooltip('Dropped by Skor, The Yeti.')
    .tooltip('Required for diamond-tier Sophisticated Storage.')

  event.create('sirok_fang')
    .displayName("Sirok's Fang")
    .rarity('rare')
    .tooltip('Dropped by Sirok, The Sandworm.')
    .tooltip('Required for Elite control circuits and 64k ME cell components.')

  event.create('helvar_sigil')
    .displayName("Helvar's Sigil")
    .rarity('epic')
    .tooltip('Dropped by Helvar, the Underworld Knight.')
    .tooltip('Required to forge Netherite Ingots.')

  event.create('nerakyss_pearl')
    .displayName("Nerakyss's Abyssal Pearl")
    .rarity('epic')
    .tooltip('Dropped by Nerakyss, The Kraken.')
    .tooltip('Required for 256k ME cell components (and everything built on them).')
})

// Botany Pots: ore-growing nerf + alloy removal.
// Checked against Botany Pots 21.1.44, Botany Pots Tiers 7.0.11 and Botany Pots: Cultivating Dreams 1.3.5.
// Base Botany Pots and Botany Trees have no ore or alloy crops; every one of them comes from Cultivating Dreams.
//
// WHY these crops are broken: each one uses the finished ingot as its seed, the matching storage block as soil,
// grows in 1200 ticks and rolls 2.5 times per harvest at 100% chance, and a harvest does not use up the seed.
// One ingot plus one block therefore becomes an endless supply. With Botany Pots Tiers a Mega pot (10x speed,
// 4x output) turns that into about 6000 items per hour from a single pot.
//
// WHAT this does:
//   1. REMOVE_* lists: these crops (and their soils) are deleted. Alloys, alloy-like metals, and the items your
//      boss-gating package locks behind a catalyst (netherite, draconium, awakened draconium).
//   2. Every other Cultivating Dreams resource crop is rebuilt with the slower grow time and lower yield of its
//      tier below. Everything else about each recipe (seed, soil, display block, drop) is copied unchanged.
//
// TUNING: edit TIERS. grow_time is in ticks (20 per second) at base speed; Tiers pots divide it by their speed
// multiplier. yield is the number of loot rolls per harvest; a fraction is a chance (0.25 = 25% chance of one
// roll). The pot's output multiplier scales yield. Set a crop's tier to 'remove' by moving it into a REMOVE list.
// Apply with /reload (or restart); check logs/kubejs/server.log for the summary line.

const TIERS = {
  //            ticks at 1x speed        loot rolls per harvest
  common:   { growTime: 24000, yield: 0.5 },   // 20 min, 0.5 rolls
  valuable: { growTime: 48000, yield: 0.25 }   // 40 min, 0.25 rolls
}

// ---- Crops removed outright -------------------------------------------------------------------------------
// Real alloys. Mekanism's three also bypass alloy_gate.js, and Evolved Mekanism's include the Creative alloy.
const REMOVE_ALLOY = [
  'mekanism/alloy_infused',
  'mekanism/alloy_reinforced',
  'mekanism/alloy_atomic',
  'evolvedmekansim/alloy_creative',
  'evolvedmekansim/alloy_exoversal',
  'evolvedmekansim/alloy_hypercharged',
  'evolvedmekansim/alloy_singular',
  'evolvedmekansim/alloy_subatomic',
]
// Metals that are alloys in everything but name (steel, bronze, and the three MEGA Cells sky alloys).
const REMOVE_ALLOY_LIKE = [
  'mekanism/ingot_steel',
  'mekanism/ingot_bronze',
  'megacells/sky_steel_ingot',
  'megacells/sky_bronze_ingot',
  'megacells/sky_osmium_ingot',
]
// Items your boss gating protects. Growing them skips the gate. Move one to a TIERS list below if you want it back.
const REMOVE_GATE_BYPASS = [
  'minecraft/netherite_ingot',
  'draconic_evolution/draconium_ingot',
  'draconic_evolution/awakened_draconium_ingot',
]

// Soil recipes for the removed crops (cosmetic cleanup: without a crop they do nothing).
const REMOVE_SOILS = [
  'mekanism/block_alloy_infused', 'mekanism/block_alloy_reinforced', 'mekanism/block_alloy_atomic',
  'evolvedmekansim/block_alloy_creative', 'evolvedmekansim/block_alloy_exoversal', 'evolvedmekansim/block_alloy_hypercharged',
  'evolvedmekansim/block_alloy_singular', 'evolvedmekansim/block_alloy_subatomic',
  'mekanism/block_steel', 'mekanism/block_bronze',
  'megacells/sky_steel_block', 'megacells/sky_bronze_block', 'megacells/sky_osmium_block',
  'draconic_evolution/draconium_block', 'draconic_evolution/awakened_draconium_block'
]

// ---- Crops kept but nerfed ----------------------------------------------------------------------------------
// [recipe id under botanypotscultivatingdreams:crops/, seed item, soil tag, display block, drop item]
const COMMON_CROPS = [
  ['minecraft/amethyst_shard', 'minecraft:amethyst_shard', 'botanypotscultivatingdreams:soil/amethyst', 'minecraft:amethyst_cluster', 'minecraft:amethyst_shard'],
  ['minecraft/clay', 'minecraft:clay_ball', 'botanypotscultivatingdreams:soil/clay', 'minecraft:clay', 'minecraft:clay_ball'],
  ['minecraft/coal', 'minecraft:coal', 'botanypotscultivatingdreams:soil/coal', 'minecraft:coal_ore', 'minecraft:coal'],
  ['minecraft/copper_ingot', 'minecraft:copper_ingot', 'botanypotscultivatingdreams:soil/copper', 'minecraft:copper_ore', 'minecraft:copper_ingot'],
  ['minecraft/glowstone', 'minecraft:glowstone_dust', 'botanypotscultivatingdreams:soil/glowstone', 'minecraft:glowstone', 'minecraft:glowstone_dust'],
  ['minecraft/iron_ingot', 'minecraft:iron_nugget', 'botanypotscultivatingdreams:soil/iron', 'minecraft:iron_ore', 'minecraft:iron_ingot'],
  ['minecraft/lapis_lazuli', 'minecraft:lapis_lazuli', 'botanypotscultivatingdreams:soil/lapis_lazuli', 'minecraft:lapis_ore', 'minecraft:lapis_lazuli'],
  ['minecraft/quartz', 'minecraft:quartz', 'botanypotscultivatingdreams:soil/quartz', 'minecraft:nether_quartz_ore', 'minecraft:quartz'],
  ['minecraft/redstone', 'minecraft:redstone', 'botanypotscultivatingdreams:soil/redstone', 'minecraft:redstone_ore', 'minecraft:redstone'],
  ['ae2/fluix_crystal', 'ae2:fluix_crystal', 'botanypotscultivatingdreams:soil/fluix', 'ae2:fluix_block', 'ae2:fluix_crystal'],
  ['ae2/quartz_cluster_crystal', 'ae2:certus_quartz_crystal', 'botanypotscultivatingdreams:soil/certus_quartz', 'ae2:quartz_cluster', 'ae2:certus_quartz_crystal'],
  ['applied_flux/harden_insulating_resin', 'appflux:harden_insulating_resin', 'botanypotscultivatingdreams:soil/harden_insulating_resin', 'botanypotscultivatingdreams:harden_insulating_resin_block', 'appflux:harden_insulating_resin'],
  ['applied_flux/redstone_crystal', 'appflux:redstone_crystal', 'botanypotscultivatingdreams:soil/redstone_crystal', 'appflux:charged_redstone_block', 'appflux:redstone_crystal'],
  ['extended_ae/silicon', 'ae2:silicon', 'botanypotscultivatingdreams:soil/silicon', 'extendedae:silicon_block', 'ae2:silicon'],
  ['fluxnetworks/flux_dust', 'fluxnetworks:flux_dust', 'botanypotscultivatingdreams:soil/flux', 'fluxnetworks:flux_block', 'fluxnetworks:flux_dust'],
  ['mekanism/charcoal', 'minecraft:charcoal', 'botanypotscultivatingdreams:soil/charcoal', 'mekanism:block_charcoal', 'minecraft:charcoal'],
  ['mekanism/fluorite_gem', 'mekanism:fluorite_gem', 'botanypotscultivatingdreams:soil/fluorite', 'mekanism:block_fluorite', 'mekanism:fluorite_gem'],
  ['mekanism/ingot_lead', 'mekanism:ingot_lead', 'botanypotscultivatingdreams:soil/lead', 'mekanism:lead_ore', 'mekanism:ingot_lead'],
  ['mekanism/ingot_osmium', 'mekanism:ingot_osmium', 'botanypotscultivatingdreams:soil/osmium', 'mekanism:osmium_ore', 'mekanism:ingot_osmium'],
  ['mekanism/ingot_tin', 'mekanism:ingot_tin', 'botanypotscultivatingdreams:soil/tin', 'mekanism:tin_ore', 'mekanism:ingot_tin'],
  ['mekanism/salt', 'mekanism:salt', 'botanypotscultivatingdreams:soil/salt', 'mekanism:block_salt', 'mekanism:salt'],
]
const VALUABLE_CROPS = [
  ['minecraft/blaze_rod', 'minecraft:blaze_rod', 'botanypotscultivatingdreams:soil/blaze', 'allthecompressed:blaze_rod_block', 'minecraft:blaze_rod'],
  ['minecraft/diamond', 'minecraft:diamond', 'botanypotscultivatingdreams:soil/diamond', 'minecraft:diamond_ore', 'minecraft:diamond'],
  ['minecraft/emerald', 'minecraft:emerald', 'botanypotscultivatingdreams:soil/emerald', 'minecraft:emerald_ore', 'minecraft:emerald'],
  ['minecraft/ender_pearl', 'minecraft:ender_pearl', 'botanypotscultivatingdreams:soil/ender_pearl', 'allthetweaks:ender_pearl_block', 'minecraft:ender_pearl'],
  ['minecraft/gold_ingot', 'minecraft:gold_ingot', 'botanypotscultivatingdreams:soil/gold', 'minecraft:gold_ore', 'minecraft:gold_ingot'],
  ['ae2/charged_quartz_cluster_crystal', 'ae2:charged_certus_quartz_crystal', 'botanypotscultivatingdreams:soil/certus_quartz', 'ae2:quartz_cluster', 'ae2:charged_certus_quartz_crystal'],
  ['applied_flux/charged_redstone', 'appflux:charged_redstone', 'botanypotscultivatingdreams:soil/charged_redstone', 'appflux:charged_redstone_block', 'appflux:charged_redstone'],
  ['evolvedmekansim/ingot_better_gold', 'evolvedmekanism:ingot_better_gold', 'botanypotscultivatingdreams:soil/better_gold', 'evolvedmekanism:block_better_gold', 'evolvedmekanism:ingot_better_gold'],
  ['evolvedmekansim/ingot_plaslitherite', 'evolvedmekanism:ingot_plaslitherite', 'botanypotscultivatingdreams:soil/plaslitherite', 'evolvedmekanism:block_plaslitherite', 'evolvedmekanism:ingot_plaslitherite'],
  ['evolvedmekansim/ingot_refined_redstone', 'evolvedmekanism:ingot_refined_redstone', 'botanypotscultivatingdreams:soil/refined_redstone', 'evolvedmekanism:block_refined_redstone', 'evolvedmekanism:ingot_refined_redstone'],
  ['extended_ae/entro_crystal', 'extendedae:entro_crystal', 'botanypotscultivatingdreams:soil/entro', 'extendedae:entro_cluster', 'extendedae:entro_ingot'],
  ['mekanism/ingot_refined_glowstone', 'mekanism:ingot_refined_glowstone', 'botanypotscultivatingdreams:soil/refined_glowstone', 'mekanism:block_refined_glowstone', 'mekanism:ingot_refined_glowstone'],
  ['mekanism/ingot_refined_obsidian', 'mekanism:ingot_refined_obsidian', 'botanypotscultivatingdreams:soil/refined_obsidian', 'mekanism:block_refined_obsidian', 'mekanism:ingot_refined_obsidian'],
  ['mekanism/ingot_uranium', 'mekanism:ingot_uranium', 'botanypotscultivatingdreams:soil/uranium', 'mekanism:uranium_ore', 'mekanism:ingot_uranium'],
  ['mekanism/pellet_plutonium', 'mekanism:pellet_plutonium', 'botanypotscultivatingdreams:soil/plutonium_pellet', 'botanypotscultivatingdreams:plutonium_block', 'mekanism:pellet_plutonium'],
  ['mekanism/pellet_polonium', 'mekanism:pellet_polonium', 'botanypotscultivatingdreams:soil/polonium_pellet', 'botanypotscultivatingdreams:polonium_block', 'mekanism:pellet_polonium'],
  ['mekanism_extras/ingot_naquadah', 'mekanism_extras:ingot_naquadah', 'botanypotscultivatingdreams:soil/naquadah', 'mekanism_extras:naquadah_ore', 'mekanism_extras:ingot_naquadah'],
  ['pneumaticcraft/ingot_iron_compressed', 'pneumaticcraft:ingot_iron_compressed', 'botanypotscultivatingdreams:soil/iron_compressed', 'pneumaticcraft:compressed_iron_block', 'pneumaticcraft:ingot_iron_compressed'],
]

ServerEvents.recipes(event => {
  const CD = 'botanypotscultivatingdreams:'

  // 1. Removals
  ;[].concat(REMOVE_ALLOY, REMOVE_ALLOY_LIKE, REMOVE_GATE_BYPASS).forEach(id => {
    event.remove({ id: CD + 'crops/' + id })
  })
  REMOVE_SOILS.forEach(id => event.remove({ id: CD + 'soil/' + id }))
  // Safety net: any alloy crop or soil from Cultivating Dreams (pots or trees) for a mod not listed above.
  event.remove({ id: /^botany(pots|trees)cultivatingdreams:.*alloy/ })

  // 2. Nerf: remove the original crop and add it back with the tier's numbers.
  const rebuild = (list, tier) => {
    list.forEach(row => {
      const id = row[0], seed = row[1], soilTag = row[2], block = row[3], drop = row[4]
      event.remove({ id: CD + 'crops/' + id })
      event.custom({
        type: 'botanypots:crop',
        input: { item: seed },
        soil: { tag: soilTag },
        grow_time: tier.growTime,
        display: { type: 'botanypots:simple', block_state: { block: block } },
        drops: [{
          type: 'botanypots:items',
          items: [{ result: { id: drop }, chance: 1.0 }]
        }],
        yield: tier.yield,
        yield_scale: 1.0
      }).id('kubejs:botany_nerf/' + id)
    })
  }
  rebuild(COMMON_CROPS, TIERS.common)
  rebuild(VALUABLE_CROPS, TIERS.valuable)

  console.info('[botany_ore_nerf] removed ' + (REMOVE_ALLOY.length + REMOVE_ALLOY_LIKE.length + REMOVE_GATE_BYPASS.length) +
    ' crops, nerfed ' + (COMMON_CROPS.length + VALUABLE_CROPS.length) + ' crops')
})

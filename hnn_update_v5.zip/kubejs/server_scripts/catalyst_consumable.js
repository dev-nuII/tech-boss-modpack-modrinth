// Catalysts are now consumables. The only way to mass-produce them is Hostile Neural Networks:
// attune a Data Model to the boss, kill it six times for real, then simulate it (see the data_models
// in kubejs/data/hostilenetworks/). The old hand-crafted duplication recipes are removed here.
// You can also delete the four *_duplication.json files from kubejs/data/kubejs/recipe/.

ServerEvents.recipes(event => {
  ;['frostbound_core', 'sirok_fang', 'helvar_sigil', 'nerakyss_pearl'].forEach(name => {
    event.remove({ id: 'kubejs:' + name + '_duplication' })
  })
  console.info('[catalyst_consumable] duplication recipes removed')
})

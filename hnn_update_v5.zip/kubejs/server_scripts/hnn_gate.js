// Gates Hostile Neural Networks itself behind the boss ladder.
//
// HNN is the only way to mass-produce catalysts, so its three machines now each need one catalyst to build:
//   Deep Learner        <- Frostbound Core   (Skor, tier 1)
//   Simulation Chamber  <- Sirok's Fang      (Sirok, tier 2)
//   Loot Fabricator     <- Helvar's Sigil    (Helvar, tier 3)
// Each catalyst is consumed by the craft, like every other catalyst in this pack.
// With the six-kill rule in the data models, that means you fight Skor, Sirok and Helvar for real
// before any catalyst can be automated.
//
// IMPORTANT: these are my own recipes, not HNN's originals. The HNN jar was not available when this was written,
// so the old recipes are removed by output item and replaced. Check JEI. If you upload the HNN jar I can keep the
// original recipes and only add the catalyst to each one.
//
// Item ids below (hostilenetworks:deep_learner, sim_chamber, loot_fabricator, prediction_matrix) are from memory of
// HNN 1.21.1. Every step is guarded with Item.exists, so a wrong id means that recipe is skipped (and logged),
// not that the script crashes. Check logs/kubejs/server.log for "[hnn_gate]" lines.
//
// TUNING: change the catalyst in GATES, or edit the patterns. Set a catalyst to null to leave that machine alone.

const GATES = [
  {
    output: 'hostilenetworks:deep_learner',
    catalyst: 'kubejs:frostbound_core',
    pattern: ['GGG', 'CFC', 'IPI'],
    key: {
      G: 'minecraft:glass_pane',
      C: 'mekanism:basic_control_circuit',
      F: 'kubejs:frostbound_core',
      I: 'minecraft:iron_ingot',
      P: 'hostilenetworks:prediction_matrix'
    }
  },
  {
    output: 'hostilenetworks:sim_chamber',
    catalyst: 'kubejs:sirok_fang',
    pattern: ['IGI', 'ASA', 'PDP'],
    key: {
      I: 'minecraft:iron_ingot',
      G: 'minecraft:glass',
      A: 'mekanism:advanced_control_circuit',
      S: 'kubejs:sirok_fang',
      P: 'hostilenetworks:prediction_matrix',
      D: 'minecraft:diamond'
    }
  },
  {
    output: 'hostilenetworks:loot_fabricator',
    catalyst: 'kubejs:helvar_sigil',
    pattern: ['IHI', 'ASA', 'PCP'],
    key: {
      I: 'minecraft:iron_ingot',
      H: 'minecraft:hopper',
      A: 'mekanism:advanced_control_circuit',
      S: 'kubejs:helvar_sigil',
      P: 'hostilenetworks:prediction_matrix',
      C: 'minecraft:chest'
    }
  }
]

ServerEvents.recipes(event => {
  if (!Platform.isLoaded('hostilenetworks')) {
    console.info('[hnn_gate] hostilenetworks is not loaded, nothing to gate')
    return
  }

  GATES.forEach(g => {
    if (!g.catalyst) return

    // Skip the whole gate if any item it mentions is missing, so we never remove a recipe we cannot replace.
    const needed = [g.output].concat(Object.keys(g.key).map(k => g.key[k]))
    const missing = needed.filter(id => !Item.exists(id))
    if (missing.length > 0) {
      console.info('[hnn_gate] SKIPPED ' + g.output + ', unknown item(s): ' + missing.join(', '))
      return
    }

    event.remove({ output: g.output })
    event.shaped(g.output, g.pattern, g.key)
      .id('kubejs:hnn_gate/' + g.output.split(':')[1])
    console.info('[hnn_gate] ' + g.output + ' now needs ' + g.catalyst)
  })
})

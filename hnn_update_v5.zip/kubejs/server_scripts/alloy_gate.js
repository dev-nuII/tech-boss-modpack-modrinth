// Gates Mekanism's reinforced and atomic alloys behind boss catalysts.
// Checked against Mekanism 10.7.19.85, Evolved Mekanism 1.3.0-fix2 and Evolved Mekanism Extras 1.2.2.
//
// Why: many Elite/Ultimate recipes use the alloy directly with no control circuit, so the circuit gate
// alone leaves them open: tier cables, pipes, tubes and conductors, energy cubes, chemical and fluid
// tanks, the laser, the atomic disassembler, robit, teleportation core, HDPE elytra, hypercharged alloy.
//
// Only one recipe in these mods makes each alloy (a Metallurgic Infuser recipe), plus Evolved Mekanism's
// block -> alloy uncrafting, which is harmless because the block itself needs alloys. We remove the two
// infuser recipes and add hand-crafting recipes that need the catalyst in the grid.
// The catalyst is now CONSUMED on every craft. Supply comes from simulating the boss with Hostile Neural
// Networks (the Loot Fabricator drop counts in kubejs/data/hostilenetworks/ set how many you get per run).
//
// Infusion values (from Mekanism's chemical_conversion recipes): 1 diamond dust = 10 diamond infusion,
// 1 refined obsidian dust = 10 refined obsidian infusion. The infuser recipes used 20 and 40 per alloy,
// so the crafts below use 2 and 4 dust per alloy. Same cost as before, plus one catalyst per craft.

ServerEvents.recipes(event => {
  event.remove({ id: 'mekanism:metallurgic_infusing/alloy/reinforced' })
  event.remove({ id: 'mekanism:metallurgic_infusing/alloy/atomic' })

  // Reinforced alloy (Tier 2: Sirok's Fang, consumed). Two per craft: 1 Fang + 2 infused alloy + 4 diamond dust.
  event.shapeless(Item.of('mekanism:alloy_reinforced', 2), [
    'kubejs:sirok_fang',
    '#mekanism:alloys/infused', '#mekanism:alloys/infused',
    '#c:dusts/diamond', '#c:dusts/diamond', '#c:dusts/diamond', '#c:dusts/diamond'
  ]).id('kubejs:alloy_gate/reinforced')

  // Atomic alloy (Tier 6: Nether Star, consumed). One per craft: 1 Star + 1 reinforced alloy + 4 refined obsidian dust.
  event.shapeless('mekanism:alloy_atomic', [
    'minecraft:nether_star',
    '#mekanism:alloys/reinforced',
    '#c:dusts/refined_obsidian', '#c:dusts/refined_obsidian', '#c:dusts/refined_obsidian', '#c:dusts/refined_obsidian'
  ]).id('kubejs:alloy_gate/atomic')

  console.info('[alloy_gate] reinforced and atomic alloy now need their catalyst')
})

# Boss-Gated Progression Package v5 (draft)

Unzip into your instance root so `kubejs/` and `config/` sit beside `mods/`.
**Add these mods first:** KubeJS (2101.x for 1.21.1 NeoForge), Rhino, Deeper and Darker (1.21.1 NeoForge) FTB Quests (2101.x), Hostile Neural Networks (1.21.1, needs Placebo). Architectury is already in your pack.
Not play-tested. Run the checklist at the bottom before trusting it.

**v5 contains everything from the v4 zip** (quests, HNN models, alloy gate, catalyst script) **plus** the Botany Pots ore nerf, an HNN machine gate, six-kill boss models and a Chaos Guardian model. Replace the v4 files if you installed them. Pieces that were already missing from the v4 zip (startup script, textures, warden_gate.js, l2hostility config) are still not in here; keep the ones you have.

## Textures
Custom 16x16 pixel art for all four catalysts lives in `kubejs/assets/kubejs/textures/item/`. Replace any PNG with your own (same filename) and reload.
If an item is missing in-game, open `logs/kubejs/startup.log` and look for a script error; the startup script registers all four items.

## The ladder

| # | Boss | Catalyst | Unlocks |
|---|---|---|---|
| 1 | Skor, the Yeti | Frostbound Core | Diamond-tier Sophisticated Storage (chests, barrels, shulkers, double chests, limited barrels, diamond tier upgrades, stack upgrade tier 4) |
| 2 | Sirok, the Sandworm | Sirok's Fang | Mekanism **Elite** control circuits (so Elite tier everything) and AE2 **64k** cell components |
| 3 | Helvar, the Underworld Knight | Helvar's Sigil | Netherite ingot crafting (and with it every netherite-tier storage recipe) |
| 4 | Nerakyss, the Kraken | Nerakyss's Abyssal Pearl | AE2 **256k** cell components, which MEGA cells build on |
| 5 | The Warden | Heart of the Deep (Deeper and Darker) | MEGA **1M** cell components and everything above them |
| 6 | Wither | Nether Star (vanilla) | Mekanism **Ultimate** control circuits; Draconic Wyvern Core (already requires one) |
| 7 | Ender Dragon | Dragon's Breath (vanilla) | NASA Workbench (the only place Ad Astra rockets are built); Draconium via dragon dust |
| 8 | Chaos Guardian | Chaos shard (Draconic) | Chaotic tier. Already gated by Draconic's own recipes. Now has an HNN model (v5) |

Not assigned: Ashlord (the Infernal Dragon). Ashlord is a natural gate for Mekanism Extras' post-Ultimate tiers.

**Catalysts are consumables.** Every catalyst is used up when you craft with it, and the hand-crafted duplication recipes are gone. The only way to mass-produce them is Hostile Neural Networks (HNN):
1. Craft a Blank Data Model and right-click it on the living boss to attune it.
2. Kill that boss **six times** for real with the model in your Deep Learner. Each kill gives 1 data and Basic, the first tier that can simulate, needs 6.
3. Run it in the Simulation Chamber, then make the catalyst in the Loot Fabricator (4 per run; 8 Nether Stars; 16 dragon breath; 4 Hearts of the Deep; 1 chaos shard).
So every gate needs six real fights per boss before it can be automated.

## Mekanism circuits
Elite and Ultimate circuits now come only from a crafting-table recipe: 4 alloys + 4 lower circuits + 1 catalyst -> 3 circuits (roughly cost-neutral). The Metallurgic Infuser routes and the Evolved Mekanism Extras alloyer routes for these two circuits are disabled so they cannot bypass the gate. Oritech's atomic forge routes are also disabled (harmless if you remove Oritech).

## Alloy gate (new in v3.2)
`kubejs/server_scripts/alloy_gate.js` removes the two Metallurgic Infuser recipes that make reinforced and atomic alloy and replaces them with crafting-table recipes that need a catalyst in the grid. The catalyst is consumed on every craft.
- Reinforced alloy: 1 Sirok's Fang + 2 infused alloy + 4 diamond dust -> 2 alloys
- Atomic alloy: 1 Nether Star + 1 reinforced alloy + 4 refined obsidian dust -> 1 alloy
Needed because many Elite and Ultimate recipes use the alloy with no circuit (tier cables, pipes, tubes, conductors, energy cubes, tanks, laser, atomic disassembler, robit, teleportation core, HDPE elytra). MekaSuit was already gated: it needs an Ultimate circuit and a netherite helmet.
Trade-off: alloys can no longer be made in the Metallurgic Infuser, so they are hand-crafted (or autocrafted with AE2).

## Other changes
- Underworld Arena vault no longer rolls netherite ingots, scrap, or ancient debris.
- Skor, Sirok, Helvar, Nerakyss keep all original drops plus one guaranteed catalyst.
- `config/l2configs/l2hostility-server.toml`: healthFactor 0.03->0.04, damageFactor 0.02->0.025, dimensionFactor 10->20, killsPerLevel 30->20. These are my starting guesses, not tested balance. Revert any line you dislike.

## Hostile Neural Networks boss models (new in v4)
`kubejs/data/hostilenetworks/data_models/bossgate/` adds models for Skor, Sirok, Helvar and Nerakyss (entity IDs `block_factorys_bosses:yeti`, `sandworm`, `underworld_knight`, `kraken`, inferred from their loot table names, so confirm with `/summon`). Overrides for HNN's own `wither`, `warden` and `ender_dragon` models raise the drop counts and make six kills reach Basic. **v5 adds a Chaos Guardian model** (`bossgate/chaos_guardian.json`, entity `draconicevolution:chaos_guardian`, 1 chaos shard per run, same 6-kill rule). The shard is the item the quest book already asks for; if you would rather keep the last boss manual, delete that one file.
`kubejs/server_scripts/catalyst_consumable.js` removes the old duplication recipes. `alloy_gate.js` now consumes its catalyst on every craft.

## Six kills per boss (new in v5)
Every boss model in `kubejs/data/hostilenetworks/data_models/` now has `data_gained.faulty = 1` (it was 6). The v4 setup assumed Basic needs 6 data, so one data per kill means six kills. If your HNN version uses a different Basic threshold, set `faulty` to threshold / kills wanted (for 6 kills at a threshold of 12, use 2). Models for Skor, Sirok, Helvar, Nerakyss, Wither, Warden, Ender Dragon and Chaos Guardian are all covered.
I read "kill 6 of the bosses" as six kills of the same boss. If you meant six *different* bosses killed before any model works, that is a different mechanism (it needs a kill counter script); say so and I will build it.

## HNN machine gate (new in v5)
`kubejs/server_scripts/hnn_gate.js` makes the three machines each need a catalyst:
- Deep Learner: 1 Frostbound Core (Skor)
- Simulation Chamber: 1 Sirok's Fang (Sirok)
- Loot Fabricator: 1 Helvar's Sigil (Helvar)

These are **my own recipes, not HNN's originals** (the HNN jar was not available). They also use Prediction Matrix, Mekanism basic/advanced circuits and vanilla parts. The script checks every item id first and skips a gate it cannot build, logging `[hnn_gate] SKIPPED` in `logs/kubejs/server.log`. Change the catalysts in the `GATES` list at the top. A new FTB Quests quest, "Hostile Neural Networks", tracks the three machines.

## Botany Pots ore nerf (new in v5)
`kubejs/server_scripts/botany_ore_nerf.js`. Botany Pots: Cultivating Dreams lets you grow ingots from an ingot seed on a storage block, and a Mega pot makes about 6000 per hour. This script:
- deletes 16 crops: all alloys (Mekanism and Evolved Mekanism, including Creative), steel, bronze, the MEGA sky alloys, and netherite, draconium and awakened draconium (they would bypass the Helvar and Dragon gates);
- rebuilds the other 39 resource crops with common = 20 min / 0.5 rolls and valuable = 40 min / 0.25 rolls (about 100x to 400x less). Per pot per hour for common crops: basic 1.5, elite 6, ultra 27, mega 60.
Tune `TIERS` at the top of the file. Mekanism alloys were previously growable, which bypassed `alloy_gate.js`; that hole is closed.

## Warden gate (new in v3.1)
`kubejs/server_scripts/warden_gate.js` keeps MEGA's own 1M cell component recipe (checked against megacells 4.11.0) and swaps its centre quartz vibrant glass for a Heart of the Deep. The 4M, 16M, 64M and 256M components each need the previous tier, so the whole MEGA line is gated.
The Warden drops exactly one Heart per kill (Deeper and Darker 1.21.1-1.4.1 loot modifier) and the Heart has no other loot source in that version.

## FTB Quests
`config/ftbquests/quests/` holds a "Boss Gating" chapter (16 quests: intro, 8 bosses, 7 unlock crafts). Untested. Replace the v3 chapter and lang files if you already installed them (quest IDs changed).

## Test checklist (creative test world)
1. `/give @s kubejs:sirok_fang` etc. All four items exist with names and icons.
2. JEI: the recipes above show the catalyst. Netherite ingot shows 4 scrap, 4 gold, 1 Sigil.
3. JEI: search every Mekanism "Elite/Ultimate Control Circuit". Only the new crafting recipe should appear. Any other source is a leak.
4. Craft a diamond chest from a gold chest; contents and upgrades must carry over.
5. `/summon` each boss and confirm the catalyst drop.
6. Craft one NASA Workbench.
7. JEI: `megacells:cell_component_1m` shows the Heart in the centre slot and no other recipe.
8. Summon a Warden and confirm it drops the Heart of the Deep.
9. JEI: `mekanism:alloy_reinforced` and `mekanism:alloy_atomic` show only the new crafting recipes (plus Evolved Mekanism's block uncrafting). Craft one and confirm the Fang / Nether Star is consumed.
10. `/give @s hostilenetworks:blank_data_model`, summon a boss, right-click it with the model, then kill it. Check the model is still Faulty after kills 1 to 5 and becomes Basic on kill 6.
11. Check JEI: no recipe duplicates a catalyst.
12. `logs/kubejs/server.log`: look for three `[hnn_gate] ... now needs ...` lines and no `SKIPPED`. In JEI, Deep Learner, Simulation Chamber and Loot Fabricator each show one catalyst and only one recipe.
13. `/summon draconicevolution:chaos_guardian` works (confirms the model's entity id), and the Chaos Guardian model attunes and reaches Basic after six kills.
14. `/give @s draconicevolution:chaos_shard` works (confirms the fabricator drop; the model marks it optional, so a wrong id fails silently).
15. Log shows `[botany_ore_nerf] removed 16 crops, nerfed 39 crops`. In JEI, no Botany Pots crop produces any alloy, steel, bronze, sky alloy, netherite or draconium, and an iron ingot crop shows a 20 minute grow time.

## Known gaps
- HNN item ids (`deep_learner`, `sim_chamber`, `loot_fabricator`, `prediction_matrix`) and the Chaos Guardian entity id are from memory and not verified against the jars. See checklist items 12 to 14.
- Whether a Mega pot's output multiplier scales Botany Pots yield exactly as assumed in the rates above is not verified.
- `botanytreescultivatingdreams` was not checked for ore trees; only an alloy catch-all covers it.
- Mekanism Extras (mekanism_extras) jar was not checked for alloy recipes of its own.
- Mekanism Unleashed: the jar I checked was 0.3.2 (your pack has 0.3.4). It adds no recipes, so it does not matter here.
- Other mods that add Heart of the Deep loot or a 1M component recipe would bypass the gate. Check JEI.
- Bastion chests can still contain loose netherite ingots. Closing that needs a loot-modification mod (e.g. LootJS).
- Diamond Sophisticated Backpacks are not gated yet.
- Advanced AE, ExtendedAE or other add-ons may have their own storage cell recipes that skip the AE2 components. Check JEI.
- Draconium can also come from draconium ore, if it generates in your world, which skips the dragon-dust path.
- Raw diamonds cannot be gated; only recipes that consume them.

// Boss catalyst items. Each is dropped by one boss and can be duplicated by recipe once you own one.
// Textures reuse vanilla item art so nothing needs a resource pack; swap later with your own PNGs in
// kubejs/assets/kubejs/textures/item/ and remove the .texture() lines.
StartupEvents.registry('item', event => {
  event.create('frostbound_core')
    .displayName('Frostbound Core')
    .texture('minecraft:item/heart_of_the_sea')
    .rarity('rare')
    .tooltip('Dropped by Skor, The Yeti.')
    .tooltip('Required for diamond-tier Sophisticated Storage.')

  event.create('helvar_sigil')
    .displayName("Helvar's Sigil")
    .texture('minecraft:item/echo_shard')
    .rarity('epic')
    .tooltip('Dropped by Helvar, the Underworld Knight.')
    .tooltip('Required to forge Netherite Ingots.')
})

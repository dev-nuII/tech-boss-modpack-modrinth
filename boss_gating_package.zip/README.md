# Boss-Gated Progression Package (draft v1)

Drop the `kubejs/` folder into your instance root (next to `mods/` and `config/`).
**Requires adding two mods:** KubeJS (the 2101.x build for 1.21.1 NeoForge) and Rhino. Architectury is already in your pack.
Not play-tested: I could not launch the game here. Run the checklist below before trusting it.

## What it does

| Gate | Catalyst | Dropped by | Locks |
|---|---|---|---|
| Diamond-tier storage | Frostbound Core | Skor, The Yeti (snowy plains hideout) | Diamond chest/barrel/shulker, double diamond chest, limited diamond barrels I-IV, all `*_to_diamond` tier upgrades, stack upgrade tier 4 |
| Netherite | Helvar's Sigil | Helvar, the Underworld Knight (nether wastes / soul sand valley arena) | Netherite ingot crafting (4 scrap + 4 gold + 1 Sigil). Every netherite-tier Sophisticated Storage recipe already uses the ingot, so netherite storage is gated too |

**Farmable once obtained:** like vanilla smithing templates, each catalyst duplicates (1 catalyst + materials -> 2).
- Frostbound Core: 4 blue ice + 4 gold ingots + 1 Core -> 2 Cores
- Helvar's Sigil: 4 soul sand + 4 nether wart + 1 Sigil -> 2 Sigils
Tune these in `kubejs/data/kubejs/recipe/*.json`.

Netherite storage needs a Sigil per ingot and a Core per diamond-tier step, so the duplication cost is the real price of automation.

## Other changes
- Underworld Arena vault no longer rolls netherite ingots, scrap, or ancient debris (it was a direct bypass).
- Skor and Helvar keep all original drops and gain one guaranteed catalyst per kill.

## Test checklist (do this in a creative test world)
1. Start the game; confirm `Frostbound Core` and `Helvar's Sigil` exist (`/give @s kubejs:frostbound_core`).
2. JEI: diamond chest recipe shows the Core in the top-left slot; netherite ingot shows 4 scrap, 4 gold, 1 Sigil.
3. Craft a diamond chest from a gold chest and check items/upgrades carry over (the custom recipe types should preserve them).
4. Duplicate each catalyst once.
5. Check JEI for *other* netherite ingot recipes added by other mods (Mekanism add-ons, Draconic). Any extra route is a leak.
6. Kill Skor and Helvar with `/summon` and confirm the drops.

## Known gaps
- **Bastion chests** can still contain loose netherite ingots/scrap, and natural ancient debris can be smelted to scrap (scrap alone is harmless; only ingots matter). Closing the chest leak needs a loot-modification mod such as LootJS.
- **Diamond Sophisticated Backpacks** are not gated yet (same family, easy to add).
- Raw diamonds can't be gated; only recipes that consume them.
